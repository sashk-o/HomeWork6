﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork6.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        [Route("[action]")]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }
        [HttpGet]
        [Route("GetRecordsById/{id:int:min(1):max(99)}")]
        public ActionResult GetRecordsById(int id)
        {
            string str = string.Format("The id passed as parameter is: {0}, Type is:  {1}", id, id.GetType());
            return Ok(str);
        }
        [HttpGet]
        [Route("GetRecordsById/{id:bool:minlength(5)}")]
        public ActionResult GetRecordsById(bool id)
        {
            string str = string.Format("The id passed as parameter is: {0}, Type is: {1}", id, id.GetType());
            return Ok(str);
        }
        [HttpGet]
        [Route("GetRecordsById/{id:datetime}")]
        public ActionResult GetRecordsById(DateTime id)
        {
            string str = string.Format("The id passed as parameter is: {0}, Type is: {1}", id, id.GetType());
            return Ok(str);
        }
        [HttpGet]
        [Route("GetRecordsById/{id:decimal:min(10000)}")]
        public ActionResult GetRecordsById(decimal id)
        {
            string str = string.Format("The id passed as parameter is: {0}, Type is: {1}", id, id.GetType());
            return Ok(str);
        }
        [HttpGet]
        [Route("GetRecordsById/{id:double:range(500, 999)}")]
        public ActionResult GetRecordsById(double id)
        {
            string str = string.Format("The id passed as parameter is: {0}, Type is: {1}", id, id.GetType());
            return Ok(str);
        }
        //[HttpGet]
        //[Route("GetRecordsById/{id:float:value(-1.1)}")]
        //public ActionResult GetRecordsById(float id)
        //{
        //    string str = string.Format("The id passed as parameter is: {0}, Type is: {1}", id, id.GetType());
        //    return Ok(str);
        //}
        [HttpGet]
        [Route("GetRecordsById/{id:guid}")]
        public ActionResult GetRecordsById(Guid id)
        {
            string str = string.Format("The id passed as parameter is: {0}, Type is: {1}", id, id.GetType());
            return Ok(str);
        }
        [HttpGet]
        [Route("GetRecordsById/{id:long:range(100, 299)}")]
        public ActionResult GetRecordsById(long id)
        {
            string str = string.Format("The id passed as parameter is: {0}, Type is: {1}", id, id.GetType());
            return Ok(str);
        }
        [HttpGet]
        [Route("GetRecordsById/{id:alpha:required:length(4)}")]
        public ActionResult GetRecordsById(string id)
        {
            string str = string.Format("The id passed as parameter is: {0}, Type is: {1}", id, id.GetType());
            return Ok(str);
        }
        [HttpGet]
        [Route("GetRecordsById/{id?}")]
        public ActionResult GetRecordsById()
        {
            string str = string.Format("The id passed as parameter is: ...");
            return Ok(str);
        }
    }
}
